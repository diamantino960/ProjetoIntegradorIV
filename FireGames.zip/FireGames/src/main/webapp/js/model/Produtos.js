class Produtos {
    constructor (elemento) {
        this._view = new View(elemento);
    }
    
    categorias (listaProdutos, categoria = '') {
        
        if ( categoria !== '' ) {
        
            var cont = '';
            listaProdutos.forEach(categorias => {
        
                if ( categorias.name === categoria ) {
        
                    cont = categorias.data.map(produto =>
                        
                        this._view.templateCategorias(produto)
                    ).join('')
                };
            });
            return cont;

        } else {

            return `${
                    
                listaProdutos.map(categorias => categorias.data.map(produto =>
                
                    this._view.templateCategorias(produto)
                ).join('')).join('')
            }`;
        }     
        
    }

    listaHTML (produtos, categoria) {
        
        return this._view.update(this.categorias(produtos, categoria));
    }
}