/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.senac.tads.pi4.firegames.Servlets;

import br.senac.tads.pi4.firegames.DAO.VendaDAO;
import br.senac.tads.pi4.firegames.Model.Venda;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Guilherme Feitosa
 */
@WebServlet(name = "Vender", urlPatterns = {"/Vender"})
public class Vender extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession sessao = request.getSession();
        Venda venda = new Venda();
       venda.setPrecototal(310.00);
       
        VendaDAO vendadados = new VendaDAO();

        vendadados.inserir(venda.getPrecototal());
        request.getRequestDispatcher("index.html").forward(request, response);

    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }
}
