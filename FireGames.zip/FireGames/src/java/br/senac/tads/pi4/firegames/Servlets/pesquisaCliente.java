/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.senac.tads.pi4.firegames.Servlets;

import br.senac.tads.pi4.firegames.DAO.ClienteDAO;
import br.senac.tads.pi4.firegames.Model.Cliente;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Guilherme Feitosa
 */
@WebServlet(name = "pesquisaCliente", urlPatterns = {"/pesquisaCliente"})
public class pesquisaCliente extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }

    Cliente cliente;
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //PESQUISAR CLIENTES
        HttpSession sessao = request.getSession();
        String pesquisa = request.getParameter("cpf");
        ClienteDAO dao = new ClienteDAO();
        cliente = dao.pesquisar(pesquisa);
        request.setAttribute("cliente", cliente);
        sessao.setAttribute("pesquisa", pesquisa);
        if(cliente.getNome() != null){
            request.getRequestDispatcher("checkout2.jsp").forward(request, response);
        }else{
            request.getRequestDispatcher("cadastrarCliente.jsp").forward(request, response); 
        }
    }
}