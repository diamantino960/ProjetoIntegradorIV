/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.senac.tads.pi4.firegames.Servlets;

import br.senac.tads.pi4.firegames.DAO.ClienteDAO;
import br.senac.tads.pi4.firegames.Model.Cliente;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Guilherme Feitosa
 */
@WebServlet(name = "loginCliente", urlPatterns = {"/loginCliente"})
public class loginCliente extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }

    Cliente cliente;
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //VALIDAR SENHA
        String pesquisa = request.getParameter("senha");
        ClienteDAO dao = new ClienteDAO();
        cliente = dao.validaSenha(pesquisa);
        request.setAttribute("cliente", cliente);
        if(cliente.getNome() != null){
            HttpSession sessao = request.getSession();

            request.getRequestDispatcher("compra.jsp").forward(request, response);
        }else{
            System.out.println("deu ruim");
    }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}