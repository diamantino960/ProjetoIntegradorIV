/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.senac.tads.pi4.firegames.Servlets;

import br.senac.tads.pi4.firegames.DAO.ProdutoDAO;
import br.senac.tads.pi4.firegames.Model.Produto;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Guilherme Feitosa
 */
@WebServlet(name = "ProdutoServlet", urlPatterns = {"/ProdutoServlet"})
public class ProdutoServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String pesquisa = request.getParameter("sku");
        Produto p = new Produto();
        ProdutoDAO produto = new ProdutoDAO();
        p = produto.pesquisar(pesquisa);
        
        p.getNomeprod();
        p.getSkuprod();
        p.getCategoriaprod();
        p.getDescricaoprod();
        p.getDiretorioprod();
        p.getPrecoprod();
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        // Jackson 2
        ObjectMapper mapper = new ObjectMapper();
        try (PrintWriter out = response.getWriter()) {
            out.print(mapper.writeValueAsString(p));
        }

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
