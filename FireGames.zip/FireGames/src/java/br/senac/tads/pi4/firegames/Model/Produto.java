/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.senac.tads.pi4.firegames.Model;

/**
 *
 * @author Guilherme Feitosa
 */
public class Produto {
    
    private String nomeprod;
    private double precoprod;
    private String categoriaprod;
    private String skuprod;
    private String diretorioprod;

    public String getNomeprod() {
        return nomeprod;
    }

    public void setNomeprod(String nomeprod) {
        this.nomeprod = nomeprod;
    }

    public double getPrecoprod() {
        return precoprod;
    }

    public void setPrecoprod(double precoprod) {
        this.precoprod = precoprod;
    }

    public String getCategoriaprod() {
        return categoriaprod;
    }

    public void setCategoriaprod(String categoriaprod) {
        this.categoriaprod = categoriaprod;
    }

    public String getSkuprod() {
        return skuprod;
    }

    public void setSkuprod(String skuprod) {
        this.skuprod = skuprod;
    }

    public String getDiretorioprod() {
        return diretorioprod;
    }

    public void setDiretorioprod(String diretorioprod) {
        this.diretorioprod = diretorioprod;
    }

    public String getDescricaoprod() {
        return descricaoprod;
    }

    public void setDescricaoprod(String descricaoprod) {
        this.descricaoprod = descricaoprod;
    }
    private String descricaoprod;

      
}
