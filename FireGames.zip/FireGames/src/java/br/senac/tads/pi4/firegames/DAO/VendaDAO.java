/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.senac.tads.pi4.firegames.DAO;

import br.senac.tads.pi4.firegames.Model.Venda;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Guilherme Feitosa
 */
public class VendaDAO {

    private Connection conexao;

    public String inserir(double precototal) {
        String message = "";
        Venda venda = new Venda();
        try {
            String sql = "INSERT INTO venda(precototal) VALUES(?)";
            conexao = ModuloConexao.conector();
            PreparedStatement stmt = conexao.prepareStatement(sql);
            stmt.setDouble(1, precototal);
            stmt.execute();
            stmt.close();
        } catch (SQLException e) {
            message = "Venda não foi criada com sucesso. erro= " + e.getMessage();
        }
        System.out.println(message);
        return message;
    }

    public ResultSet consulta() {
        Venda venda = new Venda();
        String message = "";
        ResultSet rs = null;
        try {
            conexao = ModuloConexao.conector();
            java.sql.Statement stmt = conexao.createStatement();
            String sql = "SELECT * FROM venda";
            rs = stmt.executeQuery(sql);

        } catch (SQLException e) {

        }
        return rs;
    }
}
