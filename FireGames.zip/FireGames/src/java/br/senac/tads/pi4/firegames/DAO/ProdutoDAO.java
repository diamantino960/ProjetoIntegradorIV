/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.senac.tads.pi4.firegames.DAO;

import br.senac.tads.pi4.firegames.Model.Produto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Guilherme Feitosa
 */
public class ProdutoDAO {

    private Connection conexao;

    public String inserir(Produto produto) {
        String message = "";
        try {
            String sql = "INSERT INTO tbproduto(nome, preco, categoria, sku, diretorio, descricao) VALUES(?,?,?,?,?,?)";
            conexao = ModuloConexao.conector();
            PreparedStatement stmt = conexao.prepareStatement(sql);
            stmt.setString(1, produto.getNomeprod());
            stmt.setDouble(2, produto.getPrecoprod());
            stmt.setString(3, produto.getCategoriaprod());
            stmt.setString(4, produto.getSkuprod());
            stmt.setString(5, produto.getDiretorioprod());
            stmt.setString(6, produto.getDescricaoprod());
            stmt.execute();
            stmt.close();
        } catch (SQLException e) {
            message = "Produto não foi criado com sucesso. erro= " + e.getMessage();
        }
        System.out.println(message);
        return message;
    }

    public ResultSet consulta() {
        Produto produto = new Produto();
        String message = "";
        ResultSet rs = null;
        try {
            conexao = ModuloConexao.conector();
            java.sql.Statement stmt = conexao.createStatement();
            String sql = "SELECT * FROM tbproduto";
            rs = stmt.executeQuery(sql);
            while (rs.next()) {
                produto.setNomeprod(rs.getString("nome"));
                produto.setPrecoprod(Double.parseDouble(rs.getString("preco")));
                produto.setCategoriaprod(rs.getString("categoria"));
                produto.setSkuprod(rs.getString("sku"));
                produto.setDescricaoprod(rs.getString("descricao"));
                produto.setDiretorioprod(rs.getString("diretorio"));
            }
            rs.close();
            stmt.close();
        } catch (SQLException e) {

        }
        return rs;
    }

    public Produto pesquisar(String pesquisa) {

        Produto produto = new Produto();

        try {
            conexao = ModuloConexao.conector();
            java.sql.Statement stmt = conexao.createStatement();

            String sql = "SELECT * FROM tbprodutos where sku = '" + pesquisa + "'";
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                produto.setNomeprod(rs.getString("nome"));
                produto.setSkuprod(rs.getString("sku"));
                produto.setPrecoprod(Double.parseDouble(rs.getString("preco")));
                produto.setCategoriaprod(rs.getString("categoria"));
                produto.setDescricaoprod(rs.getString("descricao"));
                produto.setDiretorioprod(rs.getString("diretorio"));

            }
            rs.close();
            stmt.close();

        } catch (SQLException e) {
            return null;
        }
        return produto;
    }
    public void alterar(Produto produto) {
        try {
            String sql = "UPDATE tbprodutos SET nome= ?, preco= ?, categoria= ?, descricao= ?, diretorio=? WHERE tbprodutos.sku = ?";
            conexao = ModuloConexao.conector();
            PreparedStatement stmt = conexao.prepareStatement(sql);
            stmt.setString(1, produto.getNomeprod());
            stmt.setDouble(2, produto.getPrecoprod());
            stmt.setString(3, produto.getCategoriaprod());
            stmt.setString(4, produto.getDescricaoprod());
            stmt.setString(5, produto.getDiretorioprod());
            stmt.setString(6, produto.getSkuprod());
            stmt.execute();
            stmt.close();
            System.out.println("Produto " + produto.getNomeprod()+ " alterado com sucesso");
        } catch (SQLException e) {
            System.out.println("Produto " + produto.getNomeprod()+ " não foi alterado com sucesso" + e.getMessage());
        }
    }
    public void deletar(Produto produto) {
        String message = "";
        try {
            String sql = "DELETE FROM tbprodutos WHERE sku = ?";
            conexao = ModuloConexao.conector();
            PreparedStatement stmt = conexao.prepareStatement(sql);
            stmt.setString(1, produto.getSkuprod());
            stmt.execute();
            stmt.close();
        } catch (SQLException e) {
            System.out.println("Produto " + produto.getNomeprod()+ "não foi excluído com sucesso" + e.getMessage());
        }
    }
}
