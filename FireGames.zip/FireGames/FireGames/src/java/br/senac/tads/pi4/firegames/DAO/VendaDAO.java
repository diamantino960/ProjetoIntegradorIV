/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.senac.tads.pi4.firegames.DAO;

import br.senac.tads.pi4.firegames.Model.Venda;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Guilherme Feitosa
 */
public class VendaDAO {

    private Connection conexao;
    Venda venda = new Venda();

    public String inserir(Venda venda) {
        String message = "";
        try {
            String sql = "INSERT INTO tbvenda(precototal, nome, sobrenome, endereco, celular, formapagamento) VALUES(?,?,?,?,?,?)";
            conexao = ModuloConexao.conector();
            PreparedStatement stmt = conexao.prepareStatement(sql);
            stmt.setDouble(1, venda.getPrecototal());
            stmt.setString(2, venda.getNome());
            stmt.setString(3, venda.getSobrenome());
            stmt.setString(4, venda.getEndereco());
            stmt.setString(5, venda.getCelular());
            stmt.setString(6, venda.getFormapagamento());
            stmt.execute();
            stmt.close();
        } catch (SQLException e) {
            message = "Venda não foi criada com sucesso. erro= " + e.getMessage();
        }
        System.out.println(message);
        return message;
    }

    public ResultSet SelectVenda() {
        Venda venda = new Venda();
        ResultSet rs = null;

        try {
            conexao = ModuloConexao.conector();
            java.sql.Statement stmt = conexao.createStatement();

            String sql = "select precototal, endereco, nome, sobrenome, datavenda, idvenda, celular, formapagamento from tbvenda ORDER BY idvenda desc LIMIT 1;";
            rs = stmt.executeQuery(sql);
            //while (rs.next()) {
            // venda.setNome(rs.getString("nome"));
            // venda.setSobrenome(rs.getString("sku"));
            // venda.setPrecototal(Double.parseDouble(rs.getString("precototal")));
            //venda.setEndereco(rs.getString("endereco"));
            // venda.setDataVenda(rs.getString("datavenda"));
            //venda.setCelular(rs.getString("celular"));
            // venda.setFormapagamento(rs.getString("formapagamento"));

            //rs.close();
            //stmt.close();
        } catch (SQLException e) {
            return null;
        }
        return rs;
    }

    public ResultSet consulta(String pesquisa1, String pesquisa2) {
        Venda venda = new Venda();
        String message = "";
        ResultSet rs = null;
        try {
            conexao = ModuloConexao.conector();
            java.sql.Statement stmt = conexao.createStatement();
            String sql = "select * from tbvenda where date_format(datavenda,'%Y-%m-%d') between '" + pesquisa1 + "' and '" + pesquisa2 + "';";
            rs = stmt.executeQuery(sql);

        } catch (SQLException e) {

        }
        return rs;
    }
}
