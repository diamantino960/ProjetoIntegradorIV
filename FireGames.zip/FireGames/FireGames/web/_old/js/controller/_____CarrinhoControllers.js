class CarrinhoControllers  {
    
    constructor (elemento) {
        let $ = document.querySelector.bind(document);
        this._carrinho = new Carrinho($(elemento));
    }

}