(function(){
    let App = {
        init: function () {
            this.getItens();
            this.click();
        },
        getItens : function () {
            let item = $('input[name="formaPag"]:checked').attr('id');
            let value = '';
            if ( item === 'bb' ) {
                value = 'Boleto Bancario';
            } else if ( item === 'cod' ) {
                value = 'Cartao de Credito';
            }
            $('input[name="formaPagamentoValue"]').val(value)
        },
        click : function () {
            
            $('input[name="formaPag"]').on('click', () => this.getItens());
        }
    };

    App.init();
})()