class ListaProdutosView {

    constructor (elemento) {

        this._elemento = elemento;
        
    }

    produto (categorias) {
        return categorias.data.map(produto =>
            this.templateListaProdutos(produto)
        ).join('')
    }
    
    exibeListaProdutos (listaProdutos, categoria) {
        return listaProdutos.map(categorias => {
                if ( categoria != '' && categorias.name == categoria ) {
                    
                  return  this.produto(categorias);

                } else if ( categoria == '' ) {
                    
                    return this.produto(categorias)
                }
            }).join('')
        
    }

    templateListaProdutos (produto) {
        
       return `<div class="single-products-catagory clearfix">
            <a href="/FireGames/${produto.sku}.html">
                <img src="/FireGames/img/bg-img/${produto.image}" alt="${produto.title}">
                <!-- Hover Content -->
                <div class="hover-content">
                    <div class="line"></div>
                    <p>Por R$ ${produto.preco}</p>
                    <h4>${produto.title}</h4>
                </div>
            </a>
        </div>`
        
    }   

    update (html) {
        this._elemento.innerHTML = html;
    } 
}