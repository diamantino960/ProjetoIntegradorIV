class ConnectionFactory {
    constructor (sessionName) {
        
        // if ( !Cookie.getCookie('sessionCookie') ) {
        //     this.clearSession();
        // }

        this.title = sessionName;
    }

    set session(item) {
        window.sessionStorage.setItem(this.title, JSON.stringify(item));
    }

    get session() {
        return JSON.parse(window.sessionStorage.getItem(this.title));
    }

    clearSession() {
        window.sessionStorage.removeItem(this.title);
    }
    
}