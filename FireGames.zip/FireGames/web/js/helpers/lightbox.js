(function () {
    console.log('entrou')
    App = {
        button: $('.btn.amado-btn'),
        text: 'Tem certeza que deseja finalizar a compra?',
        init: function () {

            $('form[action="meioPagamento"]').append(this.template());
            this.lightboxFuncionalidades();
        },
        lightboxFuncionalidades: function () {

            $('.overlayLightbox, .lightbox .closeLightbox, .cancelar').on('click', () => this.close());
            this.button.on('click', () => this.open());
        },
        open: function () {
            console.log('entrou no open');
            $('.lightbox').fadeIn('slow');
            $('.overlayLightbox').fadeIn('slow');
        },
        close: function () {
            $('.lightbox').fadeOut('slow');
            $('.overlayLightbox').fadeOut('slow');
        },
        template: function () {

            return `
                <div class="overlayLightbox"></div>
                <div class="lightbox">
                    <a href="javascript:;" class="closeLightbox">x</a>
                    <div>
                        <p>${this.text}</p>
                    </div>
                    <div class="buttons">
                        <a class="btn btn-danger cancelar" href="#">Cancelar</a>
                        <button name="ok" class="btn btn-success">Ok</button>
                    </div>
                </div>
            `
        }
    }

    App.init();

}());