class Cookie {
    static setCookie(key, value, date = 1) {
        var expires = new Date();
        expires.setTime(expires.getTime() + (date * 24 * 60 * 60 * 1000));
        document.cookie = key + '=' + value + ';expires=' + expires.toUTCString();
    }

    static getCookie(key) {
        var keyValue = document.cookie.match('(^|;) ?' + key + '=([^;]*)(;|$)');
        return keyValue ? keyValue[2] : null;
    }
}


