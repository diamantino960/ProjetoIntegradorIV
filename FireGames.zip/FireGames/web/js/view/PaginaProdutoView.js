class PaginaProdutoView {

    constructor (elemento) {

        let $ = document.querySelector.bind(document);
        this._elemento = $(elemento);
    }

    breadcrumb (infosProduto) {
        return `<div class="row">
            <div class="col-12">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mt-50">
                        <li class="breadcrumb-item"><a href="/FireGames">Home</a></li>
                        <li class="breadcrumb-item"><a href="/FireGames/shop.html?categoria=${infosProduto.name}">${infosProduto.name}</a></li>
                        <li class="breadcrumb-item active" aria-current="page">
                            ${infosProduto.data.shortName ? infosProduto.data.shortName : infosProduto.data.title}
                        </li>
                    </ol>
                </nav>
            </div>
        </div>`
    }
    criaImagensCarousel(arr = [], callback){
        return arr.map((img, hash) => callback({img, hash}));
    }

    carouselImg(infosProduto) {
        return `<div id="product_details_slider" class="carousel slide" data-ride="carousel">
                <ol class="carousel-indicators">
                    ${this.criaImagensCarousel(infosProduto.data.imagensCarousel, function(item){
                        return `<li class="${item.hash === 0 ? 'active' : ''}" data-target="#product_details_slider" data-slide-to="${item.hash}" style="background-image: url(/FireGames/img/product-img/${item.img});"></li>`
                    }).join(' ')}
                </ol>
                <div class="carousel-inner">
                    ${this.criaImagensCarousel(infosProduto.data.imagensCarousel, function(item){
                        return `<div class="carousel-item ${item.hash === 0 ? 'active':''}">
                            <a class="gallery_img" href="/FireGames/img/product-img/pro-big-1.jpg" data-hash="item-${item.hash}">
                                <img class="d-block w-100" src="/FireGames/img/product-img/${item.img}" alt="${infosProduto.data.title}" width="406" height="505">
                            </a>
                        </div>`
                    }).join(' ')}
                    
                </div>
            </div>`
    }

    informacoesProdutos(infosProduto) {
        
        return `<div class="line"></div>
        <p class="product-price">$${infosProduto.preco}</p>
        <a>
            <h6>${infosProduto.title}</h6>
        </a>`
    } 

    ratings(ratings) {
        ratings = ratings-1;
        return `<div class="ratings-review mb-15 d-flex align-items-center justify-content-between">
            <div class="ratings">
                ${(function(){
                    console.log(ratings)
                    let ratingsStar = [];
                    for(let i = 0; i < 5; i ++) {
                        console.log(i <= ratings);
                        ratingsStar.push(`<i class="fa fa-star${(i <= ratings?'':'-o')}" aria-hidden="true"></i>`)
                    }
                    return ratingsStar;
                })().join(' ')}
                </div>
            </div>`
    }

    prodDisponivel(infosProduto) {

        return `<form id="compra" class="cart clearfix">
            <input type="hidden" id="skuCompra" value="${infosProduto.sku}">
            <div class="cart-btn d-flex mb-50">
                <p>Qtd</p>
                <div class="quantity">
                    <span class="qty-minus" onclick="paginaProdutosController.QTDDc('#qty')"><i class="fa fa-caret-down" aria-hidden="true"></i></span>
                    <input type="number" class="qty-text" id="qty" step="1" min="1" max="300" name="quantity" value="1">
                    <span class="qty-plus" onclick="paginaProdutosController.QTDAc('#qty')"><i class="fa fa-caret-up" aria-hidden="true"></i></span>
                </div>
            </div>
            <button type="submit" name="addtocart" class="btn amado-btn" onclick="carrinhoController.addCart(event)">Adicionar no Carrinho</button>
        </form>`
    }
    prodIndisponivel(infosProduto) {

        return `<form class="cart clearfix" method="post">
            <button type="submit" name="indisponivel" class="btn btn-danger">Produto indisponível</button>
        </form>`
    }

    produtosView (infosProduto) {
        
        return `${this.breadcrumb(infosProduto)}
        <div class="row">
            <div class="col-12 col-lg-7">
                <div class="single_product_thumb">
                    ${this.carouselImg(infosProduto)}
                </div>
            </div>
            <div class="col-12 col-lg-5">
                <div class="single_product_desc ${infosProduto.data.estoque > 0 ? 'disponivel':'indisponivel'}">
                    <div class="product-meta-data">
                        ${this.informacoesProdutos(infosProduto.data)}
                        ${this.ratings(infosProduto.data.ratings)}
                        ${(function(){
                            if (infosProduto.data.estoque > 0) {
                                return `<p class="avaibility"><i class="fa fa-circle"></i> Disponível</p>`
                            }  else {
                                return `<p class="unavailability"><i class="fa fa-circle"></i> Indisponível</p>`
                            }
                        }())}
                    </div>
                    <div class="short_overview my-5">
                        <p>${infosProduto.data.description}</p>
                    </div>
                    ${infosProduto.data.estoque > 0 ? this.prodDisponivel(infosProduto.data) : this.prodIndisponivel(infosProduto)}
                    
                </div>
            </div>
        </div>`

    }

    criaHTML (template) {

        this._elemento.innerHTML = template;
    }

}