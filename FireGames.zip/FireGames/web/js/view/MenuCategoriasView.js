class MenuCategoriaView {
    constructor (elemento) {
        this._elemento = elemento;
    }

    template (data, categoriaAtiva) {
        return `<ul>
            ${data.map(categoria =>
               `<li class="${categoria.name === categoriaAtiva? 'active': '' }"><a href="/FireGames/shop.html?categoria=${categoria.name}">${categoria.name}</a></li>`
            ).join('')}
        </ul>`
        
    }

    update (html) {
        this._elemento.innerHTML = html;
    }
}