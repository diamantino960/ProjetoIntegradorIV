class MenuEFooterView {
    constructor () {
        this.carrinho = new Carrinho ();
    }

    activeClass (path) {
        let pathnameVerify = location.pathname.replace('/FireGames', '')
        if ( pathnameVerify === path ) {
            return `class="active"`;
        } 
        
        return '';
    }
    
    menuTemplate () {
        return `<!-- Close Icon -->
        <div class="nav-close">
            <i class="fa fa-close" aria-hidden="true"></i>
        </div>
        <!-- Logo -->
        <div class="logo">
            <a href="index.html"><img src="/FireGames/img/bg-img/logo.png" alt=""></a>
        </div>
        <!-- Amado Nav -->
        <nav class="amado-nav">
            <ul>
                <li ${this.activeClass('/')} ${this.activeClass('/index.html')}><a href="/FireGames">Home</a></li>
                <li ${this.activeClass('/shop.html')}><a href="/FireGames/shop.html">Loja</a></li>
                <!-- <li class="active"><a href="/FireGames/product-details.html">Produtos</a></li> -->
                <li ${this.activeClass('/cart.html')}><a href="/FireGames/cart.html">Carrinho</a></li>
                <li ${this.activeClass('/checkout.html')}><a href="/FireGames/checkout.html">Pagamento</a></li>
            </ul>
        </nav>
        
        <br>
        <br>
        
        <!-- Cart Menu -->
        <div class="cart-fav-search mb-100">
            <a href="cart.html" class="cart-nav"><img src="/FireGames/img/core-img/cart.png" alt=""> Carrinho <span>(${this.carrinho.qtdProdsNoCarrinho})</span></a>
            
        </div>
        <!-- Social Button -->
        <div class="social-info d-flex justify-content-between">
            <a href="https://br.pinterest.com/playstation/"><i class="fa fa-pinterest" aria-hidden="true"></i></a>
            <a href="https://www.instagram.com/playstation/"><i class="fa fa-instagram" aria-hidden="true"></i></a>
            <a href="https://www.facebook.com/PlayStationBR/"><i class="fa fa-facebook" aria-hidden="true"></i></a>
            <a href="https://twitter.com/playstation?lang=ca"><i class="fa fa-twitter" aria-hidden="true"></i></a>
        </div>`
    }

    update (elemento, template) {
        elemento.innerHTML = template;
    }
}