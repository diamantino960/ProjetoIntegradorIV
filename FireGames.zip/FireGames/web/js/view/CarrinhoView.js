class CarrinhoView {

listaProdutos (listaProdutos) {
return listaProdutos.map(produtos =>
        `<tr>
                <td class="cart_product_img">
                    <a href="/FireGames/produto/${produtos.sku}"><img src="/FireGames/img/product-img/${produtos.dadosProd.image}" alt="${produtos.dadosProd.title}"></a>
                </td>
                <td class="cart_product_desc">
                    <h5>${produtos.dadosProd.title}</h5>
                </td>
                <td class="price">
                    <span>$ ${produtos.dadosProd.preco}</span>
                </td>
                <td class="qty">
                    <div class="qty-btn d-flex">
                        <p>Qtd</p>
                        <div class="quantity">
                            <span class="qty-minus" onclick="carrinhoController.QTDDc('#qty_${produtos.sku}')"><i class="fa fa-minus" aria-hidden="true"></i></span>
                            <input type="number" class="qty-text" id="qty_${produtos.sku}" step="1" min="1" max="300" name="quantity" value="${produtos.qtd}" readonly>
                            <span class="qty-plus" onclick="carrinhoController.QTDAc('#qty_${produtos.sku}')"><i class="fa fa-plus" aria-hidden="true"></i></span>
                        </div>
                    </div>
                </td>
                <td class="excluir">
                    <a href="javascript:void(0);" onclick="carrinhoController.excluir('${produtos.sku}')">
                        <i class="fa fa-trash-o" aria-hidden="true"></i>
                        excluir
                    </a>
                </td>
            </tr>`
        ).join('')

}

resumo (listaProdutos, frete = 0) {
let totalValue = 0;
        listaProdutos.map(dados => {
        totalValue = totalValue + (parseFloat(dados.qtd) * parseFloat(dados.dadosProd.preco));
        });
        $('input[name="valueTotal"]').val(totalValue + frete);
        return `<li><span>subtotal:</span> <span>$${totalValue}</span></li>
            <li><span>frete:</span> <span>${frete ? '$' + frete:'Grátis'}</span></li>
            <li><span>total:</span> <span>$${totalValue + frete}</span></li>`
}
qtdCarrinho (qtdCart) {
return `(${qtdCart})`
}

update (elemento, template) {
elemento.innerHTML = template;
}
}