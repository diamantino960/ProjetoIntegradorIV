class MenuEFooter {
    constructor () {
        this.menu_e_footer = new MenuEFooterView();
    }
    menu (elemento) {
        this.menu_e_footer.update(elemento, this.menu_e_footer.menuTemplate());
    }
}