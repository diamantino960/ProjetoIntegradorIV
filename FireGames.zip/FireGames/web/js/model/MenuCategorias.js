class MenuCategorias {
     
    constructor (elemento) {
        this._elemento = elemento;
        this.menuCategoriaView = new MenuCategoriaView(this._elemento);
    }
            
    categorias (data, categoria) {
       
        return this.menuCategoriaView.template(data, categoria);

    }   
        
    listaHTML (categorias, categoria) {
        return this.menuCategoriaView.update(this.categorias(categorias, categoria));
    }
}