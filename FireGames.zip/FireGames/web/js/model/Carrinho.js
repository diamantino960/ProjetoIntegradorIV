class Carrinho  {
    
    constructor () {
        
        this.connectionFactory = new ConnectionFactory('transacao');
        this.connectionFactoryEnd = new ConnectionFactory('finalizar');
        this._populaCarrinho = this.connectionFactory.session ? this.connectionFactory.session : [];
        this._skuCarrinho = [];
        this._carrinhoView = new CarrinhoView();
        this._http = new HttpService();
        this._elemento = '';
        
        if (this._populaCarrinho.length && !this._skuCarrinho.length) {
            this._skuCarrinho = this.populaSkuCarrinho(this.connectionFactory.session);
        }
    }

    populaSkuCarrinho (dados) {
        return [].concat(dados.map(dados => dados.sku));
    }

    criaListaDeProdutosCarrinho(elemento) {
        this._elemento = elemento;

        this.listaProdutos.then(() => {
            if ( elemento.lista !== '' ) 
                this._carrinhoView.update(elemento.lista, this._carrinhoView.listaProdutos(this._populaCarrinho));
            
            if( elemento.resumo !== '' )
                this._carrinhoView.update(elemento.resumo, this._carrinhoView.resumo(this._populaCarrinho));
        })
    }

    QTDAc (element) {
        let qty = element.value; 
        let sku = element.attributes.id.value.split('_')[1];

        if ( !isNaN( qty ) ) {
            element.value = parseFloat(qty) + 1;
            this.alteraCriaObjCarrinho({sku, qtd:element.value}, this.listaCarrinho);
            if ( this._elemento.resumo !== '' )
                this._carrinhoView.update(this._elemento.resumo, this._carrinhoView.resumo(this._populaCarrinho));
            
            if ( this._elemento.cesta !== '' )
                this._carrinhoView.update(this._elemento.cesta, this._carrinhoView.qtdCarrinho(this.qtdProdsNoCarrinho));
        } else {
            return false;
        }

    }

    QTDDc (element) {
        let qty = element.value; 
        let sku = element.attributes.id.value.split('_')[1];

        if ( !isNaN( qty ) && qty > 1 ) {
            element.value = parseFloat(qty) - 1 ;
            this.alteraCriaObjCarrinho({sku, qtd:element.value}, this.listaCarrinho);
            if ( this._elemento.resumo !== '' )
                this._carrinhoView.update(this._elemento.resumo, this._carrinhoView.resumo(this._populaCarrinho));
            
            if ( this._elemento.cesta !== '' )
                this._carrinhoView.update(this._elemento.cesta, this._carrinhoView.qtdCarrinho(this.qtdProdsNoCarrinho));
        } else {
            return false;
        }

    }

    get listaProdutos () {
        return this._http.get('/FireGames/data.json'); 
    }

    get listaCarrinho () {
       return [].concat(this._populaCarrinho);
    }

    get skusCarrinho () {
        return [].concat(this._skuCarrinho);
    }  

    get qtdProdsNoCarrinho () {
        if ( this.listaCarrinho.length ) {
            return this.listaCarrinho.map(lista => lista.qtd).reduce((i, f) =>i + f)
        } else {
            return '0';
        }
    }

    excluir(sku) {
        
        let populaCarrinho = this._populaCarrinho.filter(data => {
            console.log('data.sku', data.sku !== sku);
            if ( data.sku !== sku ) {
                return data.sku;
            }
        });
        
        console.log(populaCarrinho);

        this._populaCarrinho = populaCarrinho;
        this.listaCarrinho;
        
        if ( this._elemento.lista !== '' )
            this._carrinhoView.update(this._elemento.lista, this._carrinhoView.listaProdutos(populaCarrinho));
        
        if ( this._elemento.resumo !== '' )
            this._carrinhoView.update(this._elemento.resumo, this._carrinhoView.resumo(populaCarrinho));
        
        if ( this._elemento.cesta !== '' )
            this._carrinhoView.update(this._elemento.cesta, this._carrinhoView.qtdCarrinho(this.qtdProdsNoCarrinho));
        
        this.connectionFactory.session = populaCarrinho;


    }

    alteraCriaObjCarrinho (compra, dados) {
        dados.filter(dadosProd => {
            if ( dadosProd.sku == compra.sku ) {
                if ( !this._skuCarrinho.includes(compra.sku) ) {
                    this._skuCarrinho.push(compra.sku);
                    this._populaCarrinho.push({sku: compra.sku, qtd: compra.qtd, dadosProd});
                } else {
                    this._populaCarrinho.filter(produto => {
                        if ( produto.sku == compra.sku ) {
                            produto.qtd = parseFloat(compra.qtd);
                        }
                    });
        
                }
            }
        })
        
        this.connectionFactory.session = this._populaCarrinho;  
    }

    objCarrinho (compra, dados) { 
        dados.forEach(categoria => categoria.data.filter(dadosProd => {
            if ( dadosProd.sku == compra.sku ) {
                if ( !this._skuCarrinho.includes(compra.sku) ) {
                    this._skuCarrinho.push(compra.sku);
                    this._populaCarrinho.push({sku: compra.sku, qtd: compra.qtd, dadosProd});
                } else {
                    this._populaCarrinho.filter(produto => {
                        if ( produto.sku == compra.sku ) {
                            produto.qtd = produto.qtd + compra.qtd;
                        }
                    });
        
                }
            }
        }))
        
        this.connectionFactory.session = this._populaCarrinho;
        return this.listaCarrinho;
    }

    finalizaCompra () {
        let objFinalizar = this._populaCarrinho.map(produto => {
            return {
                sku: produto.sku,
                qtd: produto.qtd
            }
        });
        console.log(objFinalizar);        
    }
}