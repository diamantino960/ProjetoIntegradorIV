class PaginaProdutos {
   
    constructor (elemento) {
        
        this._elemento = elemento;
        this._http = new HttpService();
        this._locationPathName = window.location.pathname;
        this._lastPathName = this.trataPathName(this._locationPathName);
        this._paginaProdutoView = new PaginaProdutoView(this._elemento);
        
    }

    trataPathName (pathName) {
        let splitPN = pathName.split('/');
        return splitPN[splitPN.length-1];
    }

    QTDAc (element) {
        let qty = element.value; 

        if ( !isNaN( qty ) ) {
            element.value = parseFloat(qty) + 1;
        } else {
            return false;
        }

    }

    QTDDc (element) {
        let qty = element.value; 

        if ( !isNaN( qty ) && qty > 1 ) {
            element.value -= 1 ;
        } else {
            return false;
        }

    }

    dataProduto () {
        return this._http.get(`/produtos/${this._lastPathName}`);
    }

    montaPagina (data) {
        return this._paginaProdutoView.criaHTML(this._paginaProdutoView.produtosView(data));
    }
    
    

}