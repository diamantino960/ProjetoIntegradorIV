class Pagamento {

    cadastrado (elemento) {

        elemento.removeClass('hidden');
        
    }

    naoCadastrado (elemento) {
        
        elemento.removeClass('hidden');
    }

    voltaParaOinicio (elemento) {

        elemento.cadastrado.addClass('hidden');
        elemento.naoCadastrado.addClass('hidden');
    }
}