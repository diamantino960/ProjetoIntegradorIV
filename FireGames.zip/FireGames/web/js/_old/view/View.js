class View {

    constructor (elemento) {

        this._elemento = elemento;
        
    }
    
    templateCategorias (produto) {
        
        

        return `<div class="single-products-catagory clearfix">
                    <a href="${produto.url}" data-sku="${produto.sku}">
                        <img src="img/bg-img/${produto.image}" alt="${produto.title}">
                        <!-- Hover Content -->
                        <div class="hover-content">
                            <div class="line"></div>
                            <p>Por R$ ${produto.preco}</p>
                            <h4>${produto.title}</h4>
                        </div>
                    </a>
                </div>`
    }   

    update (html) {
        this._elemento.innerHTML = html;
    } 
}