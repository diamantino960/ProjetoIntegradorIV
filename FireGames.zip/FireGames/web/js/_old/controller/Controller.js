class Controller {
    
    constructor (elemento) {
        let $ = document.querySelector.bind(document);
        this._http = new HttpService();
        this._produtos = new Produtos($(elemento));
        

    }

    listaProdutos (categoria) {
        return this._http.get('/FireGames/data.json').then(listaProdutos => {
            this._produtos.listaHTML(listaProdutos.section, categoria);
        });
    }
}