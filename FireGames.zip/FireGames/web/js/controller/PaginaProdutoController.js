class PaginaProdutosController {
   
    constructor (elemento) {

        this._elemento = elemento;
        this._paginaProdutos = new PaginaProdutos(this._elemento);  
    }

    QTDAc (element) {
        this._paginaProdutos.QTDAc(document.querySelector(element));
    }

    QTDDc (element) {
        this._paginaProdutos.QTDDc(document.querySelector(element));
    }

    criaEstrutura () {
        this._paginaProdutos.dataProduto().then(data => {

            this._paginaProdutos.montaPagina(data);
        });
    }
    
    

}