class PagamentoController {
    
    constructor (elementos) {
        
        this.elementos = elementos;
        this.pagamento = new Pagamento();
    }

    verificaCPF (event) {

        if ( event.target.value.length > 9 && event.target.value === '1234567890' ) {
        
            this.pagamento.cadastrado(this.elementos.cadastrado);
        } else if ( event.target.value.length > 9 ) {
        
            this.pagamento.naoCadastrado(this.elementos.naoCadastrado);
        } else {

            this.pagamento.voltaParaOinicio(this.elementos);
        }

    }
}