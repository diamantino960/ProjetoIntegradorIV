class VitrineControllers {
    
    constructor (elemento) {
        
        let $ = document.querySelector.bind(document);
        this.elemento = elemento;
        
        this._http = new HttpService();
        this._produtos = new ListaProdutos($(this.elemento.listaProdutos));

        if ( elemento.listaCategorias != null ) {
            this._menuCategorias = new MenuCategorias($(this.elemento.listaCategorias));
        }

        this._listaDeProdutos = this._http.get('/FireGames/data.json');


    }
    
    listaDeProdutos () {
        return this._listaDeProdutos;
    }

    listarProdutos (categoria) {

        return this.listaDeProdutos().then(listaProdutos => {
            this._produtos.listaHTML(listaProdutos.section, categoria);
            
            if ( this.elemento.listaCategorias ) { 
                this._menuCategorias.listaHTML(listaProdutos.section, categoria);
            }
        });
    }
}