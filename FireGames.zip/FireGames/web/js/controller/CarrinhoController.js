class CarrinhoController  {
    
    constructor () {
        
        this._carrinho = new Carrinho();
        this.connectionFactory = new ConnectionFactory();
    }

    init (elemento) {
        this._carrinho.criaListaDeProdutosCarrinho(elemento);
    }

    QTDAc (element) {
        this._carrinho.QTDAc(document.querySelector(element));
        document.querySelector('.cart-nav span')

    }

    QTDDc (element) {
        this._carrinho.QTDDc(document.querySelector(element));
    }

    addCart (_this) {
        _this.preventDefault();

        let $ = document.querySelector.bind(document);
        let qtd = parseFloat($('#compra #qty').value);
        let sku = $('#compra #skuCompra').value;
        
        let compra = {sku, qtd}
        this._carrinho.listaProdutos.then(dados => {
            this._carrinho.objCarrinho(compra, dados.section);
//            Cookie.setCookie('sessionCookie', 'true', -1);
            location.href = '/cart.html';
             
        });
    }

    excluir(sku) {
        this._carrinho.excluir(sku);
    }
    
    finalizaCompra(event) {
        event.preventDefault();
        this._carrinho.finalizaCompra();
        location.href = '/checkout.html'
    }

}