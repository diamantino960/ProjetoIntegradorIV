class ProdutosControllers {
    
    constructor (elemento) {
        
        let $ = document.querySelector.bind(document);
        this.elemento = elemento;
        
        this._http = new HttpService();
        this._produtos = new Produtos($(this.elemento.listaProdutos));

        if ( elemento.listaCategorias != null ) {
            this._menuCategorias = new MenuCategorias($(this.elemento.listaCategorias));
            this._menuCategorias.ativaMenu();
        }

        this._listaDeProdutos = this._http.get('src/data.json');

        this._carrinho = new Carrinho($('#carrinho .corpo'), $('.qtdCarrinho'));
    }

    addCart (sku) {
        produtosControllers.listaDeProdutos().then(dados => 
            this._carrinho.criaHTML(this._carrinho.objCarrinho(sku, dados))
        )
    }

    chamaCarrinho () {
        this._carrinho.initCar();
    }
    
    listaDeProdutos () {
        return this._listaDeProdutos;
    }

    listarProdutos (categoria) {

        return this.listaDeProdutos().then(listaProdutos => {
            
            this._produtos.listaHTML(listaProdutos.section, categoria);
        
            if ( this.elemento.listaCategorias ) {
                this._menuCategorias.listaHTML(listaProdutos.section);
            }
        });
    }
}