class ListaProdutosView {

    constructor (elemento) {

        this._elemento = elemento;
        
    }
    
    exibeListaProdutos (listaProdutos, categoria) {
        return `<ul> ${
            listaProdutos.map(categorias => {
                if ( categoria != '' && categorias.name == categoria ) {
                    console.log('if categorias', categorias);
                    return categorias.data.map(produto =>
                        this.templateListaProdutos(produto)
                    ).join('')
                } else if ( categoria == '' ) {
                    console.log('else')
                    return categorias.data.map(produto =>
                        this.templateListaProdutos(produto)
                    ).join('')
                }
            }).join('')
        }</ul>`
    }

    templateListaProdutos (produto) {
        
       return `<li><a href="javascript:;" onclick="produtosControllers.addCart(${produto.sku})">
            <h2>${produto.title}</h2>
            <p>${produto.description}</p>
            <img src="images/${produto.image}" alt="${produto.title}">
        </li>`
        
    }   

    update (html) {
        this._elemento.innerHTML = html;
    } 
}