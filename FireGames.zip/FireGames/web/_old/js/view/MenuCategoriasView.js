class MenuCategoriaView {
    constructor (elemento) {
        this._elemento = elemento;
    }

    template (categoria) {
        return `<li><a href="javascript:;" onclick="produtosControllers.listarProdutos('${categoria}')">${categoria}</a></li>`
    }

    update (html) {
        this._elemento.innerHTML = html;
    }
}