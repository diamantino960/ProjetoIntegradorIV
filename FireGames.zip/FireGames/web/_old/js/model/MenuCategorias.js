class MenuCategorias {
     

    constructor (elemento) {
        this.menuCategoriaView = new MenuCategoriaView(elemento);
    }
            
    categorias (data) {
        
        return `<ul>
            <h2>Categorias</h2>
            ${data.map(categoria => {
                return this.menuCategoriaView.template(categoria.name);
                
            }).join('')}
        </ul>`;
    }   

    ativaMenu () {
        console.log('activeMenu');
    }
        
    listaHTML (categorias) {
        
        return this.menuCategoriaView.update(this.categorias(categorias));
    }
}