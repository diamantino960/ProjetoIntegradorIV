class Produtos {
    constructor (elemento) {
        this.listaProdutosView = new ListaProdutosView(elemento);
    }
    
    categorias (listaProdutos, categoria = '') {
        
        return this.listaProdutosView.exibeListaProdutos(listaProdutos, categoria);
        
    }

    listaHTML (produtos, categoria) {
        
        return this.listaProdutosView.update(this.categorias(produtos, categoria));
    }
}