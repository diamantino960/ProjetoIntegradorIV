create database firegames;

use firegames;

create table venda (
idvenda int auto_increment primary key,
precototal double,
datavenda timestamp default current_timestamp,
endereco varchar(100),
cidade varchar(50),
cep varchar (20),
celular varchar (20),
formapagamento varchar(50)
);
 
drop table venda;


select * from venda;


insert into venda (precototal, endereco, cidade, cep, celular, formapagamento) 
values (199, 'Av. Joao Peixoto Viegas', 'São Paulo', '04437-000', '96051-8717', 'Cartão Crédito');