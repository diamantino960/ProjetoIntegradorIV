class Carrinho  {
    
    constructor (elemento, elementoCart) {
        this._populaCarrinho = [];
        this._skuCarrinho = [];
        this._elemento = elemento;
        this._elementoCart = elementoCart;
        this._carrinhoView = new CarrinhoView(this._elemento, this._elementoCart);
    }

    initCar() {
        let http = new HttpService();
        let listaDeProdutos = http.get('http://localhost:8080/FireGames/data.json');

        listaDeProdutos.then(listaProdutos => {
            console.log(this.listaCarrinho);
            this.criaHTMLCarrinho(this.listaCarrinho)
        })
    }

    get listaCarrinho () {
       return [].concat(this._populaCarrinho);
    }

    // get skusCarrinho () {
    //     return [].concat(this._skuCarrinho);
    // }  

    incProduto (qtd) {
        return qtd += 1;
        
    }

    decProduto (qtd) {
        return qtd -= 1;     
    }

    qtdProdsNoCarrinho () {
        return this.listaCarrinho.map(lista => lista.qtd).reduce((i, f) =>i + f)
    }
    
    objCarrinho (sku, dados) {
        dados.section.forEach(categoria => categoria.data.filter(dadosProd => {
            
            if ( dadosProd.sku == sku ) {
            
                if ( !this._skuCarrinho.includes(sku) ) {
                    this._skuCarrinho.push(sku);
                    this._populaCarrinho.push({sku, qtd: 1, dadosProd});
                } else {
                    this._populaCarrinho.filter(produto => {
                        if ( produto.sku == sku ) {
                            produto.qtd = this.incProduto(produto.qtd);
                        }
                    });
        
                }
            }
        }))
        
        return this.listaCarrinho;
    }

    criaHTMLCarrinho (dados) {
        document.querySelector('body').setAttribute('id', 'carrinho');
        document.querySelector('body#carrinho .corpo').innerHTML = '';
        setTimeout(() => this._carrinhoView.update(this._carrinhoView.template(dados)), 1000)
    }

    criaHTML (dados) {
        
        return this._carrinhoView.update(this._carrinhoView.template(dados), this._carrinhoView.qtdCarrinho(this.qtdProdsNoCarrinho()));
    }
}