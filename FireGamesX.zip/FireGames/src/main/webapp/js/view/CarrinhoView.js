class CarrinhoView {
    constructor (elemento = '', elementoCart) {
        this._elemento = elemento;
        this._elementoCart = elementoCart;
    }

    template (listaProdutos) {
        return `<ul>${
            listaProdutos.map(produtos =>
                `<li data-sku=${produtos.dadosProd.sku}>
                    <img src="images/${produtos.dadosProd.image}" />
                    <div>
                        <h2>${produtos.dadosProd.title}</h2><br />
                        <label for="qtd_${produtos.sku}"> 
                            <input type="button" class="qtd_dec" value="-" readonly />
                            qtd: <input id="qtd_${produtos.sku}" type="text" value="${produtos.qtd}" readonly>
                            <input type="button" class="qtd_inc" value="+" readonly />
                    </div>
                </li>`
            ).join('')
        }</ul>`
    }

    qtdCarrinho (qtdCart) {
        return `(${qtdCart})`
    } 

    update (html, qtdCart = '') {
        console.log('html', html);
        console.log(this._elemento);
        
        if ( this._elemento != '' ) {
            this._elemento.innerHTML = html;
        }
        
        if ( qtdCart != '' ) {
            this._elementoCart.innerHTML = qtdCart;
        }
    }
}