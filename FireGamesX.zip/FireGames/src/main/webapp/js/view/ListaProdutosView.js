class ListaProdutosView {

    constructor (elemento) {

        this._elemento = elemento;
        
    }
    
    exibeListaProdutos (listaProdutos, categoria) {
        return listaProdutos.map(categorias => {
                if ( categoria != '' && categorias.name == categoria ) {
                    console.log('if categorias', categorias);
                    return categorias.data.map(produto =>
                        this.templateListaProdutos(produto)
                    ).join('')
                } else if ( categoria == '' ) {
                    console.log('else')
                    return categorias.data.map(produto =>
                        this.templateListaProdutos(produto)
                    ).join('')
                }
            }).join('')
        
    }

    templateListaProdutos (produto) {
        
       return `<div class="single-products-catagory clearfix">
            <a href="${produto.url}" onclick="produtosControllers.addCart(${produto.sku})">
                <img src="img/bg-img/${produto.image}" alt="${produto.title}">
                <!-- Hover Content -->
                <div class="hover-content">
                    <div class="line"></div>
                    <p>Por R$ ${produto.preco}</p>
                    <h4>${produto.title}</h4>
                </div>
            </a>
        </div>`
        
    }   

    update (html) {
        this._elemento.innerHTML = html;
    } 
}